import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Book, BookService } from '../book.service';

@Component({
  selector: 'app-product-detail',
  templateUrl: './product-detail.component.html',
  styleUrls: ['./product-detail.component.css']
})
export class ProductDetailComponent implements OnInit {

  productId: String | null;
  bookService: BookService;
  book: Book;

  constructor(private route: ActivatedRoute) {
    this.productId = route.snapshot.paramMap.get("id");
    this.bookService = new BookService;
    this.book = this.bookService.getBookById(Number(this.productId));
  }

  ngOnInit(): void {
  }

}



