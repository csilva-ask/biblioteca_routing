import { Injectable } from '@angular/core';


export class Book {
  constructor(
    public id: number,
    public title: string,
    public author: string,
    public alreadyRead: boolean,
    public imageUrl: string,
    public imageUrlGr: string,
    public description: string) {
  }
}

@Injectable({
  providedIn: 'root'
})

export class BookService {
  getBooks(): Book[] {
    return books.map(b => new Book(b.id, b.title, b.author, b.alreadyRead, b.imageUrl, b.imageUrlGr, b.description));
  }
  getBookById(bookId: number): Book | any {
    return books.find(b => b.id === bookId);
  }
}

const books = [
    {
      id: 0,
      title: "Angular com Typescript",
      author: "Yakov Fain",
      alreadyRead: true,
      imageUrl: "angular.jpg",
      imageUrlGr: "angularGr.png",
      description: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Sed vitae inventore nostrum nobis! Quia, iure totam quaerat expedita laboriosam quo omnis culpa vero provident! Quis pariatur accusantium nesciunt recusandae praesentium. Lorem ipsum dolor sit, amet consectetur adipisicing elit. Sed vitae inventore nostrum nobis! Quia, iure totam quaerat expedita laboriosam quo omnis culpa vero provident! Quis pariatur accusantium nesciunt recusandae praesentium."
    },
    {
      id: 1,
      title: "Blockchain com JS",
      author: "Bina Ramahurty",
      alreadyRead: false,
      imageUrl: "blockchain.jpg",
      imageUrlGr: "blockchainGr.png",
      description: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Sed vitae inventore nostrum nobis! Quia, iure totam quaerat expedita laboriosam quo omnis culpa vero provident! Quis pariatur accusantium nesciunt recusandae praesentium. Lorem ipsum dolor sit, amet consectetur adipisicing elit. Sed vitae inventore nostrum nobis! Quia, iure totam quaerat expedita laboriosam quo omnis culpa vero provident! Quis pariatur accusantium nesciunt recusandae praesentium."
    },
    {
      id: 2,
      title: "DeepLearning com JS",
      author: "Multiple Authors",
      alreadyRead: true,
      imageUrl: "deeplearning.jpg",
      imageUrlGr: "deeplearningGr.png",
      description: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Sed vitae inventore nostrum nobis! Quia, iure totam quaerat expedita laboriosam quo omnis culpa vero provident! Quis pariatur accusantium nesciunt recusandae praesentium. Lorem ipsum dolor sit, amet consectetur adipisicing elit. Sed vitae inventore nostrum nobis! Quia, iure totam quaerat expedita laboriosam quo omnis culpa vero provident! Quis pariatur accusantium nesciunt recusandae praesentium."
    },
    {
      id: 3,
      title: "Joy of Javascript",
      author: "Luis Atencio",
      alreadyRead: true,
      imageUrl: "joj.jpg",
      imageUrlGr: "jojGr.png",
      description: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Sed vitae inventore nostrum nobis! Quia, iure totam quaerat expedita laboriosam quo omnis culpa vero provident! Quis pariatur accusantium nesciunt recusandae praesentium. Lorem ipsum dolor sit, amet consectetur adipisicing elit. Sed vitae inventore nostrum nobis! Quia, iure totam quaerat expedita laboriosam quo omnis culpa vero provident! Quis pariatur accusantium nesciunt recusandae praesentium."
    },
    {
      id: 4,
      title: "React Hooks",
      author: "John Larsen",
      alreadyRead: false,
      imageUrl: "reacthooks.jpg",
      imageUrlGr: "reacthooksGr.png",
      description: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Sed vitae inventore nostrum nobis! Quia, iure totam quaerat expedita laboriosam quo omnis culpa vero provident! Quis pariatur accusantium nesciunt recusandae praesentium. Lorem ipsum dolor sit, amet consectetur adipisicing elit. Sed vitae inventore nostrum nobis! Quia, iure totam quaerat expedita laboriosam quo omnis culpa vero provident! Quis pariatur accusantium nesciunt recusandae praesentium."
    },
    {
      id: 5,
      title: "Typescript",
      author: "Yakov Fain",
      alreadyRead: false,
      imageUrl: "typescript.png",
      imageUrlGr: "typescriptGr.png",
      description: "Lorem ipsum dolor sit, amet consectetur adipisicing elit. Sed vitae inventore nostrum nobis! Quia, iure totam quaerat expedita laboriosam quo omnis culpa vero provident! Quis pariatur accusantium nesciunt recusandae praesentium. Lorem ipsum dolor sit, amet consectetur adipisicing elit. Sed vitae inventore nostrum nobis! Quia, iure totam quaerat expedita laboriosam quo omnis culpa vero provident! Quis pariatur accusantium nesciunt recusandae praesentium."
    }
];
