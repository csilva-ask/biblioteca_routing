import { Component, OnInit } from '@angular/core';
import { Book, BookService } from '../book.service';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {

  bookService:  BookService;
  books: Book[];

  constructor() {
    this.bookService = new BookService
    this.books = this.bookService.getBooks();
   }



  ngOnInit(): void {
  }

}
